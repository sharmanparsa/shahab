هفت‌خان: دونده‌ی بام‌ها — پروژه اندروید

محتوای بازی:
- فایل اصلی HTML بدون تغییر داخل app/src/main/assets/index.html قرار داده شده است.
- اپ با WebView محلی اجرا می‌شود و JavaScript و ذخیره‌سازی localStorage فعال است.
- برای فونت‌های Google Fonts و هر منبع خارجی که خود HTML استفاده می‌کند، اینترنت لازم است.
- بازی و جزئیاتش عمداً در این بسته بازنویسی نشده‌اند.

ساخت APK:
1) Android Studio را نصب کنید.
2) از File > Open پوشه HaftKhanRunner را باز کنید.
3) اجازه دهید Gradle Sync تمام شود؛ در صورت درخواست، Android SDK 35 و JDK 17 را نصب کنید.
4) از منوی Build گزینه Build APK(s) را انتخاب کنید.
5) APK آزمایشی معمولاً در app/build/outputs/apk/debug/app-debug.apk ساخته می‌شود.

نکته:
این بسته پروژهٔ قابل‌ساخت Android Studio است، نه فایل APK کامپایل‌شده. ساخت APK نیازمند Android SDK/Gradle در محیط ساخت است.
